export HOSTNAME="$(cat /etc/hostname)"
