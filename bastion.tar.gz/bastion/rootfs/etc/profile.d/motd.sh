[ -f /etc/motd ] && cat /etc/motd
