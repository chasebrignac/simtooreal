-- ['Sales/Promotions', 'Shipping', 'Product Availability', 'Product Specifications', 'Omnichannel', 'Product Comparison', 'Returns & Refunds']
INSERT INTO public.categories values(default,'Sales/Promotions');
INSERT INTO public.categories values(default,'Shipping');
INSERT INTO public.categories values(default,'Product Availability');
INSERT INTO public.categories values(default,'Product Specifications');
INSERT INTO public.categories values(default,'Omnichannel');
INSERT INTO public.categories values(default,'Product Comparison');
INSERT INTO public.categories values(default,'Returns & Refunds');
